const Subscription = require("../models/Subscription");

// @desc    Get all subscriptions for logged in user
// @route   GET /api/subscriptions
// @access  Private
exports.getSubscriptions = async (req, res) => {
  try {
    const subscriptions = await Subscription.find({ userId: req.userId }).sort({
      createdAt: -1,
    });

    return res.status(200).json({
      success: true,
      data: subscriptions,
    });
  } catch (error) {
    console.error("getSubscriptions error:", error);
    return res.status(500).json({
      success: false,
      error: error.message || "Server error",
    });
  }
};

// @desc    Get single subscription
// @route   GET /api/subscriptions/:id
// @access  Private
exports.getSubscription = async (req, res) => {
  try {
    const subscription = await Subscription.findById(req.params.id);

    if (!subscription) {
      return res.status(404).json({
        success: false,
        error: "Subscription not found",
      });
    }

    // Verify ownership
    if (subscription.userId.toString() !== req.userId) {
      return res.status(403).json({
        success: false,
        error: "Not authorized to access this subscription",
      });
    }

    return res.status(200).json({
      success: true,
      data: subscription,
    });
  } catch (error) {
    console.error("getSubscription error:", error);
    return res.status(500).json({
      success: false,
      error: error.message || "Server error",
    });
  }
};

// @desc    Create subscription
// @route   POST /api/subscriptions
// @access  Private
exports.createSubscription = async (req, res) => {
  try {
    const { name, price, description, renewalDate, status, autoPay } = req.body;

    // Validation
    if (!name || price === undefined || !renewalDate) {
      return res.status(400).json({
        success: false,
        error: "Please provide name, price, and renewal date",
      });
    }

    if (price < 0) {
      return res.status(400).json({
        success: false,
        error: "Price cannot be negative",
      });
    }

    const subscription = await Subscription.create({
      userId: req.userId,
      name,
      price,
      description,
      renewalDate,
      status: status || "Active",
      autoPay: autoPay !== false,
    });

    return res.status(201).json({
      success: true,
      data: subscription,
    });
  } catch (error) {
    console.error("createSubscription error:", error);
    return res.status(500).json({
      success: false,
      error: error.message || "Server error",
    });
  }
};

// @desc    Update subscription
// @route   PUT /api/subscriptions/:id
// @access  Private
exports.updateSubscription = async (req, res) => {
  try {
    let subscription = await Subscription.findById(req.params.id);

    if (!subscription) {
      return res.status(404).json({
        success: false,
        error: "Subscription not found",
      });
    }

    // Verify ownership
    if (subscription.userId.toString() !== req.userId) {
      return res.status(403).json({
        success: false,
        error: "Not authorized to update this subscription",
      });
    }

    // Update fields
    const { name, price, description, renewalDate, status, autoPay } = req.body;

    if (name) subscription.name = name;
    if (price !== undefined) {
      if (price < 0) {
        return res.status(400).json({
          success: false,
          error: "Price cannot be negative",
        });
      }
      subscription.price = price;
    }
    if (description !== undefined) subscription.description = description;
    if (renewalDate) subscription.renewalDate = renewalDate;
    if (status) subscription.status = status;
    if (autoPay !== undefined) subscription.autoPay = autoPay;

    await subscription.save();

    return res.status(200).json({
      success: true,
      data: subscription,
    });
  } catch (error) {
    console.error("updateSubscription error:", error);
    return res.status(500).json({
      success: false,
      error: error.message || "Server error",
    });
  }
};

// @desc    Delete subscription
// @route   DELETE /api/subscriptions/:id
// @access  Private
exports.deleteSubscription = async (req, res) => {
  try {
    const subscription = await Subscription.findById(req.params.id);

    if (!subscription) {
      return res.status(404).json({
        success: false,
        error: "Subscription not found",
      });
    }

    // Verify ownership
    if (subscription.userId.toString() !== req.userId) {
      return res.status(403).json({
        success: false,
        error: "Not authorized to delete this subscription",
      });
    }

    await Subscription.findByIdAndDelete(req.params.id);

    return res.status(200).json({
      success: true,
      data: {},
      message: "Subscription deleted successfully",
    });
  } catch (error) {
    console.error("deleteSubscription error:", error);
    return res.status(500).json({
      success: false,
      error: error.message || "Server error",
    });
  }
};
