# Backend Setup Guide

## Prerequisites
- Node.js (v14 or higher)
- npm or yarn
- MongoDB Atlas account (free at https://www.mongodb.com/cloud/atlas)

## Step 1: Set Up MongoDB Atlas

1. Go to https://www.mongodb.com/cloud/atlas
2. Sign up for a free account (or sign in)
3. Create a new project
4. Create a cluster:
   - Select "Free" tier (M0)
   - Choose a region near you
   - Create cluster
5. Wait for cluster to be created (2-3 minutes)
6. Create a user:
   - Go to "Database Access"
   - Click "Add New Database User"
   - Username: `subscription_user` (any name)
   - Password: Create a strong password
   - Save the credentials
7. Add IP Whitelist:
   - Go to "Network Access"
   - Click "Add IP Address"
   - Select "Allow access from anywhere" (0.0.0.0/0) for development
8. Get connection string:
   - Go to "Databases"
   - Click "Connect"
   - Select "Connect your application"
   - Copy the connection string
   - Replace `<password>` with your database user password

## Step 2: Install Dependencies

```bash
cd backend
npm install
```

This installs:
- express (web framework)
- mongoose (MongoDB ODM)
- bcryptjs (password hashing)
- jsonwebtoken (JWT auth)
- cors (cross-origin requests)
- dotenv (environment variables)
- nodemon (dev auto-reload)

## Step 3: Configure Environment Variables

1. Open `.env` file in the backend folder
2. Replace `MONGODB_URI` with your connection string from Atlas
3. Generate a strong JWT_SECRET:
   ```bash
   node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
   ```
4. Paste the generated string as `JWT_SECRET`
5. Save the file

**Example .env:**
```
MONGODB_URI=mongodb+srv://subscription_user:myPassword123@cluster0.xyz.mongodb.net/subscription-db
JWT_SECRET=a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z
PORT=5000
NODE_ENV=development
CORS_ORIGIN=http://localhost:3000
```

## Step 4: Run the Backend Server

**Development mode (with auto-reload):**
```bash
npm run dev
```

**Production mode:**
```bash
npm start
```

You should see:
```
==============================
🚀 Server Running
==============================
PORT: 5000
ENV: development
URL: http://localhost:5000
API: http://localhost:5000/api
==============================
```

## Step 5: Test the API

### Using curl or Postman:

**1. Register a new user:**
```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "John Doe",
    "email": "john@example.com",
    "password": "password123"
  }'
```

Response will include a `token`.

**2. Login:**
```bash
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "john@example.com",
    "password": "password123"
  }'
```

**3. Get current user (requires token):**
```bash
curl -X GET http://localhost:5000/api/auth/me \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

**4. Create a subscription (requires token):**
```bash
curl -X POST http://localhost:5000/api/subscriptions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -d '{
    "name": "Netflix",
    "price": 15.99,
    "renewalDate": "2026-05-06",
    "status": "Active",
    "autoPay": true,
    "description": "Monthly subscription"
  }'
```

**5. Get all subscriptions (requires token):**
```bash
curl -X GET http://localhost:5000/api/subscriptions \
  -H "Authorization: Bearer YOUR_TOKEN_HERE"
```

## Step 6: Connect Frontend to Backend

1. Open terminal in the subscription-manager folder (frontend)
2. Create a `.env` file:
   ```
   REACT_APP_API_URL=http://localhost:5000/api
   ```
3. Restart the React development server
4. Test the login/registration flow

## Troubleshooting

### "Cannot connect to MongoDB"
- Check MongoDB URI in .env
- Verify IP whitelist in MongoDB Atlas Network Access
- Ensure password doesn't have special characters that need encoding

### "Port 5000 already in use"
- Change PORT in .env to a different port (e.g., 5001)
- Or kill the process using port 5000

### "CORS error when calling from frontend"
- Check CORS_ORIGIN in .env matches your frontend URL
- Default is http://localhost:3000

### "Token expired"
- JWT tokens expire in 30 days
- User needs to login again

## API Endpoints Summary

### Auth
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `GET /api/auth/me` - Get current user (requires token)

### Subscriptions (all require authentication token)
- `GET /api/subscriptions` - Get all subscriptions
- `POST /api/subscriptions` - Create subscription
- `GET /api/subscriptions/:id` - Get single subscription
- `PUT /api/subscriptions/:id` - Update subscription
- `DELETE /api/subscriptions/:id` - Delete subscription

## Security Features Implemented
✅ Password hashing with bcryptjs (10 rounds)
✅ JWT tokens with 30-day expiration
✅ User ownership validation (users can only access their own subscriptions)
✅ Input validation on all endpoints
✅ CORS protection
✅ Secure environment variables (.env not committed to git)

## Next Steps
1. Set up MongoDB Atlas account
2. Update `.env` with your credentials
3. Run `npm install` in backend folder
4. Run `npm run dev` to start the server
5. Test with curl/Postman
6. Connect frontend and test the full flow
