# Subscription Manager - Full Setup Guide

Complete setup instructions for the Subscription Manager app (Frontend + Backend)

## Project Structure

```
subscription-manager/
├── public/                  # Static files
├── src/                    # React frontend
│   ├── components/
│   ├── pages/
│   ├── context/           # AppContext for state management
│   ├── services/          # API client
│   ├── App.js
│   ├── index.js
│   └── App.css
├── server/                 # Node.js + Express backend
│   ├── models/
│   ├── routes/
│   ├── middleware/
│   ├── server.js
│   ├── package.json
│   └── .env
├── package.json
└── README.md
```

---

## Frontend Setup

### Prerequisites
- Node.js v14 or higher
- npm or yarn

### Installation

1. **Install dependencies:**
```bash
npm install
```

2. **Start the development server:**
```bash
npm start
```

Frontend runs on `http://localhost:3000`

### Features (Offline Mode)
- Login with any email + password (min 6 chars)
- Add, edit, delete subscriptions
- Search and filter subscriptions
- Budget tracking (monthly/yearly costs)
- All data saved to browser localStorage

---

## Backend Setup

### Prerequisites
- Node.js v14 or higher
- MongoDB (local or Atlas)

### Installation

1. **Navigate to server directory:**
```bash
cd server
```

2. **Install dependencies:**
```bash
npm install
```

3. **Configure environment variables:**

Create/edit `.env` file:
```
PORT=5000
MONGODB_URI=mongodb://localhost:27017/subscription-manager
JWT_SECRET=your_jwt_secret_key_change_this_in_production
NODE_ENV=development
```

**MongoDB Setup:**

**Option 1: Local MongoDB**
- Install MongoDB from https://www.mongodb.com/try/download/community
- Run MongoDB with: `mongod`
- Use: `MONGODB_URI=mongodb://localhost:27017/subscription-manager`

**Option 2: MongoDB Atlas (Cloud)**
- Create account at https://www.mongodb.com/cloud/atlas
- Create a cluster and get connection string
- Update `.env`: `MONGODB_URI=mongodb+srv://user:password@cluster.mongodb.net/subscription-manager`

4. **Start the backend server:**

Development (with auto-reload):
```bash
npm run dev
```

Production:
```bash
npm start
```

Backend runs on `http://localhost:5000`

---

## Connect Frontend to Backend

1. **Update frontend API configuration:**

The frontend automatically uses backend API when available. In `src/services/api.js`:
- Backend URL defaults to `http://localhost:5000/api`
- Can be customized with `REACT_APP_API_URL` env variable

2. **Update frontend .env (optional):**

Create `.env` in root directory:
```
REACT_APP_API_URL=http://localhost:5000/api
```

3. **Restart frontend:**
```bash
npm start
```

---

## Running Both Frontend & Backend

### Option 1: Two Terminal Windows

**Terminal 1 (Frontend):**
```bash
npm start
```

**Terminal 2 (Backend):**
```bash
cd server
npm run dev
```

### Option 2: Using Concurrently

Install globally:
```bash
npm install -g concurrently
```

From root directory:
```bash
npm install concurrently --save-dev
```

Add to `package.json`:
```json
"scripts": {
  "dev": "concurrently \"npm start\" \"cd server && npm run dev\""
}
```

Run:
```bash
npm run dev
```

---

## API Documentation

### Authentication Endpoints

**Register**
```
POST /api/auth/register
Body: { name, email, password }
```

**Login**
```
POST /api/auth/login
Body: { email, password }
Returns: { token, user }
```

**Get Current User**
```
GET /api/auth/me
Headers: Authorization: Bearer <token>
```

### Subscription Endpoints (Protected)

**Get All Subscriptions**
```
GET /api/subscriptions
Headers: Authorization: Bearer <token>
```

**Create Subscription**
```
POST /api/subscriptions
Headers: Authorization: Bearer <token>
Body: { name, price, description, renewalDate, status }
```

**Update Subscription**
```
PUT /api/subscriptions/:id
Headers: Authorization: Bearer <token>
Body: { name, price, description, renewalDate, status }
```

**Delete Subscription**
```
DELETE /api/subscriptions/:id
Headers: Authorization: Bearer <token>
```

---

## Features

### Frontend Features
✅ User Authentication (email + password)
✅ Add/Edit/Delete Subscriptions
✅ Search Subscriptions
✅ Filter by Status (Active, Paused, Cancelled)
✅ Sort by Name, Price, Renewal Date
✅ Budget Tracking (Monthly & Yearly Costs)
✅ Real Service Logos
✅ Responsive Design
✅ Dark Theme
✅ Protected Routes

### Backend Features
✅ JWT Authentication
✅ Password Hashing (bcryptjs)
✅ MongoDB Database
✅ RESTful API
✅ User-specific Subscriptions
✅ Error Handling
✅ CORS Support

---

## Troubleshooting

### MongoDB Connection Error
- Ensure MongoDB is running
- Check connection string in `.env`
- For MongoDB Atlas, whitelist your IP

### Port Already in Use
- Frontend uses 3000, Backend uses 5000
- Change in `.env` if needed

### CORS Error
- Backend has CORS enabled by default
- Check if frontend URL matches backend CORS config

### API Not Responding
- Ensure backend is running: `npm run dev`
- Check backend URL in frontend `src/services/api.js`
- Check firewall/antivirus blocking ports

### Authentication Issues
- Ensure JWT_SECRET is set in `.env`
- Check token format: `Authorization: Bearer <token>`
- Token expires in 7 days

---

## Next Steps

1. **Deploy Backend** - Deploy to Heroku, Railway, or AWS
2. **Deploy Frontend** - Deploy to Vercel, Netlify, or GitHub Pages
3. **Production Settings** - Update JWT_SECRET and API URLs
4. **Database Backups** - Set up MongoDB Atlas backups
5. **Monitoring** - Add error logging and analytics

---

## Support

For issues or questions, check:
- `/server/README.md` - Backend documentation
- GitHub issues or documentation
