# Subscription Manager - Backend API

Node.js + Express REST API for Subscription Manager

## Setup Instructions

### Prerequisites
- Node.js v14 or higher
- MongoDB installed locally or MongoDB Atlas account

### Installation

1. **Install dependencies:**
```bash
npm install
```

2. **Configure environment variables:**

Edit `.env` file:
```
PORT=5000
MONGODB_URI=mongodb://localhost:27017/subscription-manager
JWT_SECRET=your_jwt_secret_key_change_this_in_production
NODE_ENV=development
```

**MongoDB Setup:**
- **Local:** Install MongoDB and ensure it's running on `mongodb://localhost:27017`
- **Cloud:** Use MongoDB Atlas - create a cluster and replace `MONGODB_URI` in .env

3. **Start the server:**

Development (with auto-reload):
```bash
npm run dev
```

Production:
```bash
npm start
```

Server will run on `http://localhost:5000`

## API Endpoints

### Authentication

**Register**
- POST `/api/auth/register`
- Body: `{ name, email, password }`
- Returns: `{ token, user }`

**Login**
- POST `/api/auth/login`
- Body: `{ email, password }`
- Returns: `{ token, user }`

**Get Current User**
- GET `/api/auth/me`
- Headers: `Authorization: Bearer <token>`
- Returns: `{ user }`

### Subscriptions (Protected - require JWT token)

**Get all subscriptions**
- GET `/api/subscriptions`
- Headers: `Authorization: Bearer <token>`

**Get single subscription**
- GET `/api/subscriptions/:id`
- Headers: `Authorization: Bearer <token>`

**Create subscription**
- POST `/api/subscriptions`
- Headers: `Authorization: Bearer <token>`
- Body: `{ name, price, description, renewalDate, status }`

**Update subscription**
- PUT `/api/subscriptions/:id`
- Headers: `Authorization: Bearer <token>`
- Body: `{ name, price, description, renewalDate, status }`

**Delete subscription**
- DELETE `/api/subscriptions/:id`
- Headers: `Authorization: Bearer <token>`

## Project Structure

```
server/
├── models/
│   ├── User.js          # User schema
│   └── Subscription.js  # Subscription schema
├── routes/
│   ├── auth.js          # Auth endpoints
│   └── subscriptions.js # Subscription CRUD endpoints
├── middleware/
│   └── auth.js          # JWT protection middleware
├── server.js            # Main server file
├── package.json
├── .env                 # Environment variables
└── .gitignore
```

## Next Steps: Connect Frontend

Update `src/config/api.js` in your React app:

```javascript
export const API_BASE_URL = 'http://localhost:5000/api';
```

Update API calls to use the backend instead of localStorage.

## Troubleshooting

**MongoDB Connection Error:**
- Ensure MongoDB is running: `mongo --version`
- Check MONGODB_URI in .env
- For MongoDB Atlas, whitelist your IP address

**Port Already in Use:**
- Change PORT in .env to `5001` or kill the process using port 5000

**JWT Token Issues:**
- Ensure JWT_SECRET is set in .env
- Token format: `Authorization: Bearer <token>`
