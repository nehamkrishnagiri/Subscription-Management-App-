const express = require("express");
const router = express.Router();
const Subscription = require("../models/Subscription");
const { protect } = require("../middleware/auth");

// Get all subscriptions for logged-in user
router.get("/", protect, async (req, res) => {
  try {
    const subscriptions = await Subscription.find({ userId: req.user.id }).sort({
      createdAt: -1,
    });
    res.json(subscriptions);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get single subscription
router.get("/:id", protect, async (req, res) => {
  try {
    const subscription = await Subscription.findById(req.params.id);

    if (!subscription) {
      return res.status(404).json({ error: "Subscription not found" });
    }

    // Check if user owns the subscription
    if (subscription.userId.toString() !== req.user.id) {
      return res.status(401).json({ error: "Not authorized" });
    }

    res.json(subscription);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create subscription
router.post("/", protect, async (req, res) => {
  try {
    const { name, price, description, renewalDate, status } = req.body;

    // Validation
    if (!name || price === undefined || !renewalDate) {
      return res.status(400).json({ error: "Please provide all required fields" });
    }

    const subscription = await Subscription.create({
      userId: req.user.id,
      name,
      price,
      description,
      renewalDate,
      status: status || "Active",
    });

    res.status(201).json(subscription);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update subscription
router.put("/:id", protect, async (req, res) => {
  try {
    let subscription = await Subscription.findById(req.params.id);

    if (!subscription) {
      return res.status(404).json({ error: "Subscription not found" });
    }

    // Check if user owns the subscription
    if (subscription.userId.toString() !== req.user.id) {
      return res.status(401).json({ error: "Not authorized" });
    }

    subscription = await Subscription.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
        runValidators: true,
      }
    );

    res.json(subscription);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Delete subscription
router.delete("/:id", protect, async (req, res) => {
  try {
    const subscription = await Subscription.findById(req.params.id);

    if (!subscription) {
      return res.status(404).json({ error: "Subscription not found" });
    }

    // Check if user owns the subscription
    if (subscription.userId.toString() !== req.user.id) {
      return res.status(401).json({ error: "Not authorized" });
    }

    await Subscription.findByIdAndDelete(req.params.id);

    res.json({ message: "Subscription deleted" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
