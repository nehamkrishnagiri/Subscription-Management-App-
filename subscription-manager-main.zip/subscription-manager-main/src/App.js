import React, { useContext } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Navbar from "./components/Navbar";
import Dashboard from "./pages/Dashboard";
import AddSubscription from "./pages/AddSubscription";
import Login from "./pages/Login";
import SignUp from "./pages/SignUp";
import { AppProvider, AppContext } from "./context/AppContext";
import "./App.css";

// Protected Route Component
const ProtectedRoute = ({ element }) => {
  const { isAuthenticated } = useContext(AppContext);
  return isAuthenticated ? element : <Navigate to="/login" />;
};

function AppContent() {
  const { isAuthenticated } = useContext(AppContext);

  return (
    <Router>
      <div className="App">
        <Navbar />
        <main className="app-container">
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<SignUp />} />
            <Route
              path="/"
              element={<ProtectedRoute element={<Dashboard />} />}
            />
            <Route
              path="/add"
              element={<ProtectedRoute element={<AddSubscription />} />}
            />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

export default App;
