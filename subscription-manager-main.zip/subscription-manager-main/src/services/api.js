// API base URL - adjust based on environment
export const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

// Helper function to make API requests with auth token
export const apiCall = async (endpoint, method = 'GET', body = null) => {
  const token = localStorage.getItem('token');

  const options = {
    method,
    headers: {
      'Content-Type': 'application/json',
    },
  };

  if (token) {
    options.headers.Authorization = `Bearer ${token}`;
  }

  if (body) {
    options.body = JSON.stringify(body);
  }

  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, options);
    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || 'API request failed');
    }

    return data;
  } catch (error) {
    console.warn('Backend API unavailable, using localStorage fallback:', error);
    return null;
  }
};

// Auth APIs
export const authAPI = {
  register: async (name, email, password) => {
    const result = await apiCall('/auth/register', 'POST', { name, email, password });
    if (result) return result;
    // Fallback: simple localStorage auth
    return { token: 'demo_' + Date.now(), user: { name, email } };
  },
  login: async (email, password) => {
    const result = await apiCall('/auth/login', 'POST', { email, password });
    if (result) return result;
    // Fallback: simple localStorage auth
    return { token: 'demo_' + Date.now(), user: { email, name: email.split('@')[0] } };
  },
  getCurrentUser: () => apiCall('/auth/me', 'GET'),
};

// Subscription APIs
export const subscriptionsAPI = {
  getAll: async () => {
    const result = await apiCall('/subscriptions', 'GET');
    if (result) return result.data || [];
    // Fallback to localStorage
    const saved = localStorage.getItem('subscriptions');
    return saved ? JSON.parse(saved) : [];
  },
  getOne: (id) => apiCall(`/subscriptions/${id}`, 'GET'),
  create: async (subscription) => {
    const result = await apiCall('/subscriptions', 'POST', subscription);
    if (result) return result.data;
    // Fallback: create locally
    return { ...subscription, id: Date.now() };
  },
  update: async (id, subscription) => {
    const result = await apiCall(`/subscriptions/${id}`, 'PUT', subscription);
    if (result) return result.data;
    // Fallback: update locally
    return { ...subscription, id };
  },
  delete: (id) => apiCall(`/subscriptions/${id}`, 'DELETE'),
};

