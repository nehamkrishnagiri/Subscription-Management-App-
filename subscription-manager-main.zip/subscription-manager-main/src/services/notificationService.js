// Service to handle browser notifications
export const NotificationService = {
  // Request permission if not already granted
  requestPermission: async () => {
    if (!('Notification' in window)) {
      console.log('This browser does not support notifications');
      return false;
    }

    if (Notification.permission === 'granted') {
      return true;
    }

    if (Notification.permission !== 'denied') {
      try {
        const permission = await Notification.requestPermission();
        return permission === 'granted';
      } catch (error) {
        console.error('Error requesting notification permission:', error);
        return false;
      }
    }

    return false;
  },

  // Send a notification
  sendNotification: (title, options = {}) => {
    if (!('Notification' in window)) {
      console.log('This browser does not support notifications');
      return;
    }

    if (Notification.permission === 'granted') {
      try {
        new Notification(title, {
          icon: '/favicon.ico',
          ...options,
        });
      } catch (error) {
        console.error('Error sending notification:', error);
      }
    }
  },

  // Send reminder notifications for subscriptions
  sendReminderNotifications: (subscriptions) => {
    if (!subscriptions || subscriptions.length === 0) {
      return;
    }

    const now = new Date();

    subscriptions.forEach((subscription) => {
      const renewalDate = new Date(subscription.renewalDate);
      const daysUntilRenewal = Math.ceil((renewalDate - now) / (1000 * 60 * 60 * 24));

      // Send notification for payments due
      if (daysUntilRenewal <= 0) {
        NotificationService.sendNotification(
          `💰 Payment Due: ${subscription.name}`,
          {
            body: `AutoPay will deduct $${subscription.price} from your account for ${subscription.name}`,
            tag: `payment-due-${subscription.id}`,
            requireInteraction: true,
          }
        );
      }
      // Send notification for payments due soon
      else if (daysUntilRenewal <= 3) {
        NotificationService.sendNotification(
          `⏰ Renewal Reminder: ${subscription.name}`,
          {
            body: `${subscription.name} renews in ${daysUntilRenewal} day${daysUntilRenewal > 1 ? 's' : ''}. AutoPay: $${subscription.price}`,
            tag: `payment-soon-${subscription.id}`,
          }
        );
      }
    });
  },
};
