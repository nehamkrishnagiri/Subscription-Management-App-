import React, { useState, useContext } from "react";
import { useNavigate } from "react-router-dom";
import { AppContext } from "../context/AppContext";

const AddSubscription = () => {
  const { addSubscription } = useContext(AppContext);
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    price: "",
    description: "",
    renewalDate: "",
    status: "Active",
    autoPay: true,
  });
  const [error, setError] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (!formData.name.trim()) {
      setError("Subscription name is required");
      return;
    }
    if (!formData.price || parseFloat(formData.price) < 0) {
      setError("Valid price is required");
      return;
    }
    if (!formData.renewalDate) {
      setError("Renewal date is required");
      return;
    }

    try {
      await addSubscription(formData);
      navigate("/");
    } catch (err) {
      setError(err.message || "Failed to add subscription");
    }
  };

  return (
    <div className="add-subscription">
      <h2>➕ Add New Subscription</h2>
      <form onSubmit={handleSubmit} className="subscription-form">
        {error && <div className="error-message">{error}</div>}

        <div className="form-group">
          <label htmlFor="name">Subscription Name *</label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="e.g., Netflix, Spotify, etc."
          />
        </div>

        <div className="form-group">
          <label htmlFor="price">Price (Monthly) *</label>
          <input
            type="number"
            id="price"
            name="price"
            value={formData.price}
            onChange={handleChange}
            placeholder="0.00"
            step="0.01"
            min="0"
          />
        </div>

        <div className="form-group">
          <label htmlFor="description">Description</label>
          <textarea
            id="description"
            name="description"
            value={formData.description}
            onChange={handleChange}
            placeholder="Add notes about this subscription (optional)"
          />
        </div>

        <div className="form-group">
          <label htmlFor="renewalDate">Renewal Date *</label>
          <input
            type="date"
            id="renewalDate"
            name="renewalDate"
            value={formData.renewalDate}
            onChange={handleChange}
          />
        </div>

        <div className="form-group">
          <label htmlFor="status">Status</label>
          <select
            id="status"
            name="status"
            value={formData.status}
            onChange={handleChange}
          >
            <option value="Active">Active</option>
            <option value="Paused">Paused</option>
            <option value="Cancelled">Cancelled</option>
          </select>
        </div>

        <div className="form-group checkbox-group">
          <label htmlFor="autoPay">
            <input
              type="checkbox"
              id="autoPay"
              name="autoPay"
              checked={formData.autoPay}
              onChange={(e) =>
                setFormData((prev) => ({
                  ...prev,
                  autoPay: e.target.checked,
                }))
              }
            />
            <span>Enable AutoPay (Automatic renewal)</span>
          </label>
        </div>

        <button type="submit" className="btn btn-primary">
          Add Subscription
        </button>
      </form>
    </div>
  );
};

export default AddSubscription;
