import React, { useContext, useState, useMemo } from "react";
import { AppContext } from "../context/AppContext";
import SubscriptionCard from "../components/SubscriptionCard";

const Dashboard = () => {
  const {
    subscriptions,
    deleteSubscription,
    editSubscription,
    bankAccounts,
    linkBankAccount,
    removeBankAccount,
    refreshBankBalances,
  } = useContext(AppContext);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterAutoPay, setFilterAutoPay] = useState("all");
  const [sortBy, setSortBy] = useState("name");
  const [editingId, setEditingId] = useState(null);
  const [editFormData, setEditFormData] = useState({});
  const [bankModalOpen, setBankModalOpen] = useState(false);
  const [bankFormData, setBankFormData] = useState({
    name: "",
    institution: "",
    accountNumber: "",
    availableBalance: "",
  });

  // Calculate budget statistics
  const budgetStats = useMemo(() => {
    const total = subscriptions.reduce((sum, sub) => sum + parseFloat(sub.price || 0), 0);
    const activeCount = subscriptions.filter(
      (sub) => sub.status.toLowerCase() === "active"
    ).length;

    const autoPayCount = subscriptions.filter((sub) => sub.autoPay).length;

    return {
      monthly: total.toFixed(2),
      yearly: (total * 12).toFixed(2),
      activeCount,
      totalCount: subscriptions.length,
      autoPayCount,
    };
  }, [subscriptions]);

  const normalizeDate = (dateString) => {
    const date = new Date(dateString);
    const normalized = new Date(date);
    normalized.setHours(0, 0, 0, 0);
    return normalized;
  };

  const totalAvailableBalance = useMemo(() => {
    return bankAccounts
      .reduce((sum, account) => sum + parseFloat(account.availableBalance || 0), 0)
      .toFixed(2);
  }, [bankAccounts]);

  const totalLinkedAccounts = bankAccounts.length;

  const upcomingRenewals = useMemo(() => {
    const today = normalizeDate(new Date());
    const twoDaysFromNow = new Date(today);
    twoDaysFromNow.setDate(today.getDate() + 2);

    return subscriptions.filter((sub) => {
      const renewalDate = normalizeDate(sub.renewalDate);
      return (
        renewalDate >= today &&
        renewalDate <= twoDaysFromNow &&
        sub.status.toLowerCase() === "active"
      );
    });
  }, [subscriptions]);

  const dueTodayRenewals = useMemo(() => {
    const today = normalizeDate(new Date());

    return subscriptions.filter((sub) => {
      const renewalDate = normalizeDate(sub.renewalDate);
      return (
        renewalDate.getTime() === today.getTime() &&
        sub.status.toLowerCase() === "active"
      );
    });
  }, [subscriptions]);

  const weeklyRenewals = useMemo(() => {
    const today = normalizeDate(new Date());
    const sevenDaysFromNow = new Date(today);
    sevenDaysFromNow.setDate(today.getDate() + 7);

    return subscriptions.filter((sub) => {
      const renewalDate = normalizeDate(sub.renewalDate);
      return (
        renewalDate >= today &&
        renewalDate <= sevenDaysFromNow &&
        sub.status.toLowerCase() === "active"
      );
    });
  }, [subscriptions]);

  const upcomingCost = useMemo(() => {
    return weeklyRenewals
      .reduce((sum, sub) => sum + parseFloat(sub.price || 0), 0)
      .toFixed(2);
  }, [weeklyRenewals]);

  const handleBankChange = (e) => {
    const { name, value } = e.target;
    setBankFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleOpenBankModal = () => {
    setBankModalOpen(true);
  };

  const handleCloseBankModal = () => {
    setBankModalOpen(false);
    setBankFormData({
      name: "",
      institution: "",
      accountNumber: "",
      availableBalance: "",
    });
  };

  const handleLinkBankAccount = async () => {
    try {
      await linkBankAccount(bankFormData);
      handleCloseBankModal();
    } catch (err) {
      console.error("Failed to link bank account:", err);
      alert("Unable to link bank account. Please try again.");
    }
  };

  const handleRemoveBankAccount = async (id) => {
    try {
      await removeBankAccount(id);
    } catch (err) {
      console.error("Failed to remove bank account:", err);
    }
  };

  const handleRefreshBalances = async () => {
    try {
      await refreshBankBalances();
    } catch (err) {
      console.error("Failed to refresh balances:", err);
    }
  };

  // Filter and search subscriptions
  const filteredSubscriptions = useMemo(() => {
    let filtered = subscriptions.filter((sub) => {
      const matchesSearch = sub.name
        .toLowerCase()
        .includes(searchTerm.toLowerCase());
      const matchesStatus =
        filterStatus === "all" ||
        sub.status.toLowerCase() === filterStatus.toLowerCase();
      const matchesAutoPay =
        filterAutoPay === "all" ||
        (filterAutoPay === "enabled" && sub.autoPay) ||
        (filterAutoPay === "disabled" && !sub.autoPay);
      return matchesSearch && matchesStatus && matchesAutoPay;
    });

    // Sort subscriptions
    filtered.sort((a, b) => {
      switch (sortBy) {
        case "price":
          return b.price - a.price;
        case "date":
          return new Date(b.renewalDate) - new Date(a.renewalDate);
        case "name":
        default:
          return a.name.localeCompare(b.name);
      }
    });

    return filtered;
  }, [subscriptions, searchTerm, filterStatus, filterAutoPay, sortBy]);

  const handleEdit = (id) => {
    const subscription = subscriptions.find((sub) => sub.id === id);
    if (subscription) {
      setEditingId(id);
      // Format date for HTML input (YYYY-MM-DD)
      const formattedDate = subscription.renewalDate
        ? new Date(subscription.renewalDate).toISOString().split('T')[0]
        : '';
      setEditFormData({
        ...subscription,
        renewalDate: formattedDate,
      });
    }
  };

  const handleEditChange = (e) => {
    const { name, value } = e.target;
    setEditFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSaveEdit = async () => {
    try {
      const dataToSave = {
        ...editFormData,
        price: parseFloat(editFormData.price),
        renewalDate: new Date(editFormData.renewalDate).toISOString(),
      };
      await editSubscription(editingId, dataToSave);
      setEditingId(null);
      setEditFormData({});
    } catch (error) {
      console.error("Error saving edit:", error);
      alert("Failed to save changes. Please try again.");
    }
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setEditFormData({});
  };

  return (
    <div className="dashboard">
      <h2>📊 Dashboard</h2>
      {/* Budget Stats */}
      <div className="budget-stats">
        <div className="stat-card">
          <div className="stat-icon">💰</div>
          <div className="stat-content">
            <p className="stat-label">Monthly Cost</p>
            <p className="stat-value">${budgetStats.monthly}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">📅</div>
          <div className="stat-content">
            <p className="stat-label">Yearly Cost</p>
            <p className="stat-value">${budgetStats.yearly}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">✅</div>
          <div className="stat-content">
            <p className="stat-label">Active</p>
            <p className="stat-value">{budgetStats.activeCount}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">💡</div>
          <div className="stat-content">
            <p className="stat-label">AutoPay</p>
            <p className="stat-value">{budgetStats.autoPayCount}</p>
          </div>
        </div>
        <div className="stat-card stat-card-accent">
          <div className="stat-icon">📆</div>
          <div className="stat-content">
            <p className="stat-label">Due Today</p>
            <p className="stat-value">{dueTodayRenewals.length}</p>
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">📦</div>
          <div className="stat-content">
            <p className="stat-label">Total</p>
            <p className="stat-value">{budgetStats.totalCount}</p>
          </div>
        </div>

        <div className="stat-card stat-card-accent">
          <div className="stat-icon">⚠️</div>
          <div className="stat-content">
            <p className="stat-label">Due Soon</p>
            <p className="stat-value">{upcomingRenewals.length}</p>
          </div>
        </div>

        <div className="stat-card stat-card-accent">
          <div className="stat-icon">💳</div>
          <div className="stat-content">
            <p className="stat-label">Next 7d Cost</p>
            <p className="stat-value">${upcomingCost}</p>
          </div>
        </div>
      </div>

      {/* Bank Accounts */}
      <div className="bank-section">
        <div className="bank-header">
          <div>
            <h3>🏦 Bank Accounts</h3>
            <p className="bank-summary-text">
              {totalLinkedAccounts} linked account{totalLinkedAccounts !== 1 ? "s" : ""} • Total available ${totalAvailableBalance}
            </p>
          </div>
          <div className="bank-actions">
            <button className="btn btn-primary" onClick={handleOpenBankModal}>
              Link Bank Account
            </button>
            <button className="btn btn-secondary" onClick={handleRefreshBalances}>
              Refresh Balance
            </button>
          </div>
        </div>

        {bankAccounts.length > 0 ? (
          <div className="bank-list">
            {bankAccounts.map((account) => (
              <div key={account.id} className="bank-card">
                <div>
                  <p className="bank-name">{account.name}</p>
                  <p className="bank-institution">{account.institution}</p>
                  <p className="bank-account-number">•••• {account.accountNumber.slice(-4)}</p>
                </div>
                <div className="bank-card-right">
                  <p className="bank-balance">${parseFloat(account.availableBalance).toFixed(2)}</p>
                  <button className="btn btn-delete small" onClick={() => handleRemoveBankAccount(account.id)}>
                    Remove
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="no-upcoming">No bank accounts linked yet.</p>
        )}
      </div>

      {/* Upcoming Renewals */}
      <div className="upcoming-renewals">
        <h3>🔄 Upcoming Renewals (Next 2 Days)</h3>
        {upcomingRenewals.length > 0 ? (
          <div className="subscriptions-container">
            {upcomingRenewals.map((subscription) => (
              <SubscriptionCard
                key={subscription.id}
                subscription={subscription}
                onDelete={deleteSubscription}
                onEdit={handleEdit}
              />
            ))}
          </div>
        ) : (
          <p className="no-upcoming">No subscriptions renewing in the next 2 days.</p>
        )}
      </div>

      <div className="upcoming-renewals upcoming-weekly">
        <h3>📈 Renewals This Week</h3>
        {weeklyRenewals.length > 0 ? (
          <>
            <p className="weekly-summary">
              {weeklyRenewals.length} subscription{weeklyRenewals.length > 1 ? "s" : ""} renewing in the next 7 days for a total of ${upcomingCost}.
            </p>
            <div className="subscriptions-container">
              {weeklyRenewals.map((subscription) => (
                <SubscriptionCard
                  key={subscription.id}
                  subscription={subscription}
                  onDelete={deleteSubscription}
                  onEdit={handleEdit}
                />
              ))}
            </div>
          </>
        ) : (
          <p className="no-upcoming">No subscriptions renewing in the next 7 days.</p>
        )}
      </div>

      {/* Link Bank Account Modal */}
      {bankModalOpen && (
        <div className="modal-overlay">
          <div className="modal-content">
            <h3>Link Bank Account</h3>
            <form className="edit-form">
              <div className="form-group">
                <label htmlFor="bank-name">Account Name</label>
                <input
                  type="text"
                  id="bank-name"
                  name="name"
                  value={bankFormData.name}
                  onChange={handleBankChange}
                />
              </div>
              <div className="form-group">
                <label htmlFor="bank-institution">Institution</label>
                <input
                  type="text"
                  id="bank-institution"
                  name="institution"
                  value={bankFormData.institution}
                  onChange={handleBankChange}
                />
              </div>
              <div className="form-group">
                <label htmlFor="bank-accountNumber">Account Number</label>
                <input
                  type="text"
                  id="bank-accountNumber"
                  name="accountNumber"
                  value={bankFormData.accountNumber}
                  onChange={handleBankChange}
                  placeholder="Last 4 digits"
                />
              </div>
              <div className="form-group">
                <label htmlFor="bank-availableBalance">Available Balance</label>
                <input
                  type="number"
                  id="bank-availableBalance"
                  name="availableBalance"
                  value={bankFormData.availableBalance}
                  onChange={handleBankChange}
                  step="0.01"
                  min="0"
                />
              </div>
              <div className="modal-actions">
                <button type="button" className="btn btn-primary" onClick={handleLinkBankAccount}>
                  Link Account
                </button>
                <button type="button" className="btn btn-cancel" onClick={handleCloseBankModal}>
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Search and Filter */}
      <div className="dashboard-controls">
        <div className="search-box">
          <input
            type="text"
            placeholder="🔍 Search subscriptions..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="search-input"
          />
        </div>
        <div className="filter-group">
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="filter-select"
          >
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="paused">Paused</option>
            <option value="cancelled">Cancelled</option>
          </select>

          <select
            value={filterAutoPay}
            onChange={(e) => setFilterAutoPay(e.target.value)}
            className="filter-select"
          >
            <option value="all">All AutoPay</option>
            <option value="enabled">AutoPay Enabled</option>
            <option value="disabled">AutoPay Disabled</option>
          </select>

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="filter-select"
          >
            <option value="name">Sort by Name</option>
            <option value="price">Sort by Price</option>
            <option value="date">Sort by Renewal Date</option>
          </select>
        </div>
      </div>

      {/* Edit Modal */}
      {editingId && (
        <div className="modal-overlay">
          <div className="modal-content">
            <h3>Edit Subscription</h3>
            <form className="edit-form">
              <div className="form-group">
                <label htmlFor="edit-name">Subscription Name</label>
                <input
                  type="text"
                  id="edit-name"
                  name="name"
                  value={editFormData.name || ""}
                  onChange={handleEditChange}
                />
            
              </div>

              <div className="form-group">
                <label htmlFor="edit-price">Price (Monthly)</label>
                <input
                  type="number"
                  id="edit-price"
                  name="price"
                  value={editFormData.price || ""}
                  onChange={handleEditChange}
                  step="0.01"
                  min="0"
                />
              </div>

              <div className="form-group">
                <label htmlFor="edit-description">Description</label>
                <textarea
                  id="edit-description"
                  name="description"
                  value={editFormData.description || ""}
                  onChange={handleEditChange}
                />
              </div>

              <div className="form-group">
                <label htmlFor="edit-renewalDate">Renewal Date</label>
                <input
                  type="date"
                  id="edit-renewalDate"
                  name="renewalDate"
                  value={editFormData.renewalDate || ""}
                  onChange={handleEditChange}
                />
              </div>

              <div className="form-group">
                <label htmlFor="edit-status">Status</label>
                <select
                  id="edit-status"
                  name="status"
                  value={editFormData.status || "Active"}
                  onChange={handleEditChange}
                >
                  <option value="Active">Active</option>
                  <option value="Paused">Paused</option>
                  <option value="Cancelled">Cancelled</option>
                </select>
              </div>

              <div className="form-group checkbox-group">
                <label htmlFor="edit-autoPay">
                  <input
                    type="checkbox"
                    id="edit-autoPay"
                    name="autoPay"
                    checked={editFormData.autoPay || false}
                    onChange={(e) =>
                      setEditFormData((prev) => ({
                        ...prev,
                        autoPay: e.target.checked,
                      }))
                    }
                  />
                  <span>Enable AutoPay</span>
                </label>
              </div>

              <div className="modal-actions">
                <button
                  type="button"
                  className="btn btn-primary"
                  onClick={handleSaveEdit}
                >
                  Save Changes
                </button>
                <button
                  type="button"
                  className="btn btn-cancel"
                  onClick={handleCancelEdit}
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Subscriptions Grid */}
      {filteredSubscriptions.length > 0 ? (
        <div className="subscriptions-container">
          {filteredSubscriptions.map((subscription) => (
            <SubscriptionCard
              key={subscription.id}
              subscription={subscription}
              onDelete={deleteSubscription}
              onEdit={handleEdit}
            />
          ))}
        </div>
      ) : (
        <div className="no-subscriptions">
          {subscriptions.length === 0
            ? "📭 No subscriptions yet. Add one to get started!"
            : "❌ No subscriptions match your search."}
        </div>
      )}
    </div>
  );
};

export default Dashboard;
