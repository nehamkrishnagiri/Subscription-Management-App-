import React, { createContext, useState, useEffect } from "react";
import { authAPI, subscriptionsAPI } from "../services/api";
import { NotificationService } from "../services/notificationService";

export const AppContext = createContext();

export const AppProvider = ({ children }) => {
  const [subscriptions, setSubscriptions] = useState(() => {
    const saved = localStorage.getItem("subscriptions");
    return saved ? JSON.parse(saved) : [];
  });

  const [bankAccounts, setBankAccounts] = useState(() => {
    const saved = localStorage.getItem("bankAccounts");
    return saved ? JSON.parse(saved) : [];
  });

  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    const token = localStorage.getItem("token");
    const user = localStorage.getItem("user");
    return token !== null || user !== null;
  });

  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem("user");
    return saved ? JSON.parse(saved) : null;
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Save to localStorage whenever subscriptions change
  useEffect(() => {
    localStorage.setItem("subscriptions", JSON.stringify(subscriptions));
  }, [subscriptions]);

  // Save linked bank accounts to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("bankAccounts", JSON.stringify(bankAccounts));
  }, [bankAccounts]);

  // Fetch subscriptions from backend if authenticated
  useEffect(() => {
    const fetchSubscriptions = async () => {
      const token = localStorage.getItem("token");
      if (token) {
        try {
          setLoading(true);
          const data = await subscriptionsAPI.getAll();
          // Convert MongoDB _id to id for consistency
          const normalized = data.map(sub => ({
            ...sub,
            id: sub.id || sub._id,
          }));
          setSubscriptions(normalized);
          
          // Request notification permission and send reminders
          const permissionGranted = await NotificationService.requestPermission();
          if (permissionGranted) {
            NotificationService.sendReminderNotifications(normalized);
          }
        } catch (err) {
          console.error("Failed to fetch subscriptions:", err);
        } finally {
          setLoading(false);
        }
      }
    };

    fetchSubscriptions();
  }, [isAuthenticated]);

  const addSubscription = async (subscription) => {
    try {
      const token = localStorage.getItem("token");
      if (token) {
        // Use backend API
        const newSub = await subscriptionsAPI.create(subscription);
        // Normalize the response
        const normalized = {
          ...newSub,
          id: newSub.id || newSub._id,
        };
        setSubscriptions([...subscriptions, normalized]);
      } else {
        // Fallback to localStorage
        const newSubscription = {
          ...subscription,
          id: Date.now(),
        };
        setSubscriptions([...subscriptions, newSubscription]);
      }
    } catch (err) {
      setError(err.message);
    }
  };

  const deleteSubscription = async (id) => {
    try {
      const token = localStorage.getItem("token");
      if (token) {
        // Use backend API
        await subscriptionsAPI.delete(id);
      }
      setSubscriptions(subscriptions.filter((sub) => sub.id !== id && sub._id !== id));
    } catch (err) {
      setError(err.message);
    }
  };

  const editSubscription = async (id, updatedData) => {
    try {
      const token = localStorage.getItem("token");
      if (token) {
        // Use backend API
        const updated = await subscriptionsAPI.update(id, updatedData);
        // Normalize the response
        const normalized = {
          ...updated,
          id: updated.id || updated._id,
        };
        setSubscriptions(
          subscriptions.map((sub) =>
            (sub.id === id || sub._id === id) ? normalized : sub
          )
        );
      } else {
        // Fallback to localStorage
        setSubscriptions(
          subscriptions.map((sub) =>
            sub.id === id ? { ...sub, ...updatedData } : sub
          )
        );
      }
    } catch (err) {
      setError(err.message);
      throw err;
    }
  };

  const linkBankAccount = async (account) => {
    try {
      const newAccount = {
        ...account,
        id: Date.now(),
        availableBalance: parseFloat(account.availableBalance || 0),
      };
      setBankAccounts((prev) => [...prev, newAccount]);
      return newAccount;
    } catch (err) {
      setError(err.message);
      throw err;
    }
  };

  const removeBankAccount = async (id) => {
    try {
      setBankAccounts((prev) => prev.filter((acct) => acct.id !== id));
    } catch (err) {
      setError(err.message);
      throw err;
    }
  };

  const refreshBankBalances = async () => {
    try {
      // Placeholder for a real bank provider refresh.
      return bankAccounts;
    } catch (err) {
      setError(err.message);
      throw err;
    }
  };

  const login = async (email, password) => {
    try {
      setLoading(true);
      setError(null);

      // Try backend API first
      try {
        const response = await authAPI.login(email, password);
        localStorage.setItem("token", response.token);
        localStorage.setItem("user", JSON.stringify(response.user));
        setUser(response.user);
        setIsAuthenticated(true);
        return true;
      } catch (apiError) {
        // Fallback to localStorage authentication for demo
        if (email && password.length >= 6) {
          const userData = { email, name: email.split("@")[0] };
          localStorage.setItem("user", JSON.stringify(userData));
          localStorage.setItem("token", "demo_" + Date.now()); // Set a demo token for persistence
          setUser(userData);
          setIsAuthenticated(true);
          return true;
        }
        throw apiError;
      }
    } catch (err) {
      setError(err.message);
      return false;
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    setIsAuthenticated(false);
    // Don't clear subscriptions - they should persist for the account
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    localStorage.removeItem("isAuthenticated");
  };

  const register = async (name, email, password) => {
    try {
      setLoading(true);
      setError(null);

      // Try backend API first
      try {
        const response = await authAPI.register(name, email, password);
        localStorage.setItem("token", response.token);
        localStorage.setItem("user", JSON.stringify(response.user));
        setUser(response.user);
        setIsAuthenticated(true);
        return true;
      } catch (apiError) {
        // Fallback to localStorage authentication for demo
        const userData = { name, email };
        localStorage.setItem("user", JSON.stringify(userData));
        localStorage.setItem("token", "demo_" + Date.now());
        setUser(userData);
        setIsAuthenticated(true);
        return true;
      }
    } catch (err) {
      setError(err.message);
      return false;
    } finally {
      setLoading(false);
    }
  };

  const value = {
    subscriptions,
    bankAccounts,
    addSubscription,
    deleteSubscription,
    editSubscription,
    linkBankAccount,
    removeBankAccount,
    refreshBankBalances,
    isAuthenticated,
    user,
    login,
    logout,
    register,
    loading,
    error,
  };

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};
