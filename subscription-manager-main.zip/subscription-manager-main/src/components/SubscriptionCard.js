import React from "react";

// Logo/image mapping for popular subscriptions with CDN URLs
const getSubscriptionLogo = (name) => {
  const logos = {
    netflix: "https://img.icons8.com/color/96/000000/netflix.png",
    spotify: "https://img.icons8.com/color/96/000000/spotify.png",
    youtube: "https://img.icons8.com/color/96/000000/youtube.png",
    "youtube music": "https://img.icons8.com/color/96/000000/youtube-music.png",
    "youtube premium": "https://img.icons8.com/color/96/000000/youtube-play.png",
    amazon: "https://img.icons8.com/color/96/000000/amazon.png",
    "amazon prime": "https://img.icons8.com/color/96/000000/amazon.png",
    "prime video": "https://img.icons8.com/color/96/000000/amazon.png",
    disney: "https://img.icons8.com/color/96/000000/disney.png",
    "disney+": "https://img.icons8.com/color/96/000000/disney.png",
    hulu: "https://img.icons8.com/color/96/000000/hulu.png",
    hbo: "https://img.icons8.com/color/96/000000/hbo.png",
    "hbo max": "https://img.icons8.com/color/96/000000/hbo.png",
    apple: "https://img.icons8.com/color/96/000000/apple-tv.png",
    "apple tv": "https://img.icons8.com/color/96/000000/apple-tv.png",
    "apple music": "https://img.icons8.com/color/96/000000/apple-music.png",
    twitch: "https://img.icons8.com/color/96/000000/twitch.png",
    xbox: "https://img.icons8.com/color/96/000000/xbox.png",
    "xbox game pass": "https://img.icons8.com/color/96/000000/xbox.png",
    playstation: "https://img.icons8.com/color/96/000000/playstation.png",
    "ps plus": "https://img.icons8.com/color/96/000000/playstation.png",
    microsoft: "https://img.icons8.com/color/96/000000/microsoft.png",
    "office 365": "https://img.icons8.com/color/96/000000/ms-word.png",
    "microsoft 365": "https://img.icons8.com/color/96/000000/ms-word.png",
    dropbox: "https://img.icons8.com/color/96/000000/dropbox.png",
    google: "https://img.icons8.com/color/96/000000/google-logo.png",
    "google one": "https://img.icons8.com/color/96/000000/google-drive.png",
    icloud: "https://img.icons8.com/color/96/000000/icloud.png",
    onedrive: "https://img.icons8.com/color/96/000000/microsoft-onedrive.png",
    notion: "https://img.icons8.com/color/96/000000/notion.png",
    medium: "https://img.icons8.com/color/96/000000/medium-new.png",
    canva: "https://img.icons8.com/color/96/000000/canva.png",
    adobe: "https://img.icons8.com/color/96/000000/adobe-creative-cloud.png",
    "adobe creative cloud": "https://img.icons8.com/color/96/000000/adobe-creative-cloud.png",
    slack: "https://img.icons8.com/color/96/000000/slack-new.png",
    discord: "https://img.icons8.com/color/96/000000/discord.png",
    default: "https://img.icons8.com/color/96/000000/credit-card.png",
  };

  const lowerName = name.toLowerCase();
  return logos[lowerName] || logos["default"];
};

const SubscriptionCard = ({ subscription, onDelete, onEdit }) => {
  const logoUrl = getSubscriptionLogo(subscription.name);

  // Check if subscription is due soon (within 2 days)
  const renewalDate = new Date(subscription.renewalDate);
  const today = new Date();
  const daysUntilRenewal = Math.ceil((renewalDate - today) / (1000 * 60 * 60 * 24));
  const isDueSoon = daysUntilRenewal <= 2 && daysUntilRenewal > 0;
  const isDue = daysUntilRenewal <= 0;

  return (
    <div className={`subscription-card ${isDue ? "card-due" : ""} ${isDueSoon ? "card-due-soon" : ""}`}>
      {isDue && (
        <div className="notification-banner payment-due">
          🔔 Payment Due! AutoPay will deduct ${subscription.price} from your account
        </div>
      )}
      {isDueSoon && !isDue && (
        <div className="notification-banner payment-soon">
          ⏰ Due in {daysUntilRenewal} day{daysUntilRenewal > 1 ? "s" : ""}! AutoPay: ${subscription.price}
        </div>
      )}
      <div className="card-header">
        <div className="card-title-section">
          <img
            src={logoUrl}
            alt={subscription.name}
            className="subscription-logo"
            onError={(e) => {
              e.target.style.display = "none";
            }}
          />
          <h3 className="card-title">{subscription.name}</h3>
        </div>
        <span className="card-price">${subscription.price}</span>
      </div>
      <div className="card-body">
        {subscription.description && (
          <p className="card-description">{subscription.description}</p>
        )}
        <p className="card-date">
          <strong>Next Renewal:</strong> {subscription.renewalDate}
        </p>
        <p className="card-status">
          <strong>Status:</strong>{" "}
          <span className={`status-badge status-${subscription.status.toLowerCase()}`}>
            {subscription.status}
          </span>
        </p>
        <p className="card-autopay">
          <strong>AutoPay:</strong> {subscription.autoPay ? "✅ Enabled" : "❌ Disabled"}
        </p>
      </div>
      <div className="card-actions">
        <button
          className="btn btn-edit"
          onClick={() => onEdit(subscription.id)}
        >
          Edit
        </button>
        <button
          className="btn btn-delete"
          onClick={() => onDelete(subscription.id)}
        >
          Delete
        </button>
      </div>
    </div>
  );
};

export default SubscriptionCard;
