# 💳 Subscription Manager - Full Stack Application

A modern web application for managing and tracking your subscriptions with payment due alerts, budget tracking, and multi-user support.

## ✨ Features

### 🎯 Core Features
- ✅ **User Authentication** - Secure registration and login with JWT tokens
- ✅ **Subscription Management** - Create, read, update, delete subscriptions
- ✅ **Smart Notifications** - Payment due alerts and upcoming renewal warnings
- ✅ **AutoPay Status** - Display autopay enabled/disabled for each subscription
- ✅ **Budget Tracking** - Calculate monthly and yearly subscription costs
- ✅ **Search & Filter** - Find subscriptions by name, status (Active/Paused/Cancelled)
- ✅ **Sorting** - Sort by name, price, or renewal date
- ✅ **Real Service Logos** - Display logos for Netflix, Spotify, Disney+, and 30+ services
- ✅ **Password Security** - Bcryptjs hashing with 10 salt rounds
- ✅ **Offline Mode** - localStorage fallback when backend unavailable
- ✅ **Dark Theme** - Modern black background UI with color accents

## 🛠 Tech Stack

### Frontend
- **React 18** - UI library
- **React Router v6** - Client-side routing
- **Context API** - State management
- **CSS3** - Styling with animations
- **JavaScript ES6+** - Logic

### Backend
- **Node.js** - Runtime
- **Express.js** - REST API framework
- **MongoDB** - NoSQL database (Atlas cloud)
- **Mongoose** - ODM for MongoDB
- **JWT** - Authentication tokens
- **Bcryptjs** - Password hashing
- **CORS** - Cross-origin requests

## 📁 Project Structure

```
subscription-manager/
├── src/                          (React Frontend)
│   ├── components/
│   │   ├── Navbar.js
│   │   └── SubscriptionCard.js
│   ├── pages/
│   │   ├── Dashboard.js
│   │   ├── AddSubscription.js
│   │   └── Login.js
│   ├── context/
│   │   └── AppContext.js
│   ├── services/
│   │   └── api.js
│   ├── App.js
│   ├── App.css
│   └── index.js
│
├── backend/                     (Node.js Backend)
│   ├── controllers/
│   ├── models/
│   ├── routes/
│   ├── middleware/
│   ├── config/
│   ├── server.js
│   ├── package.json
│   └── .env
│
├── BACKEND_SETUP.md
├── package.json
└── README.md
```

## 🚀 Quick Start

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn
- MongoDB Atlas account (free at https://www.mongodb.com/cloud/atlas)

### Frontend Setup
```bash
# Install dependencies
npm install

# Start development server
npm start
```
Opens http://localhost:3000

### Backend Setup
```bash
# Navigate to backend
cd backend

# Install dependencies
npm install

# Create .env file (copy from .env.example)
cp .env.example .env

# Add your MongoDB URI and JWT secret to .env

# Start development server
npm run dev
```
Runs on http://localhost:5000

### Database Setup
1. Visit https://www.mongodb.com/cloud/atlas
2. Create free tier cluster
3. Create database user (save username/password)
4. Add IP to network access (0.0.0.0/0 for development)
5. Copy connection string
6. Update `backend/.env` with MONGODB_URI

## 📖 API Documentation

### Authentication
```
POST /api/auth/register
POST /api/auth/login
GET /api/auth/me (requires token)
```

### Subscriptions (all require token)
```
GET /api/subscriptions
POST /api/subscriptions
GET /api/subscriptions/:id
PUT /api/subscriptions/:id
DELETE /api/subscriptions/:id
```

See [BACKEND_SETUP.md](./BACKEND_SETUP.md) for detailed API examples.

## 🔐 Security Features
- Bcryptjs password hashing (10 salt rounds)
- JWT authentication with 30-day expiration
- User ownership validation
- CORS protection
- Input validation on all endpoints
- Secure environment variables

## 📊 Key Features Explained

### Budget Tracking
- Real-time monthly/yearly cost calculation
- Active subscription count tracking
- Total subscription monitoring

### Payment Notifications
- 🔴 **Payment Due** - Red banner when renewal date passed
- 🟡 **Due Soon** - Yellow banner within 3 days of renewal
- AutoPay amount display

### Service Logos
Netflix, Spotify, YouTube, Disney+, Hulu, HBO, Apple TV, Amazon Prime, Twitch, Xbox, PlayStation, Microsoft, Google, Dropbox, iCloud, OneDrive, Notion, and 15+ more!

### Offline Support
- All data persisted to localStorage
- Works completely offline
- Automatic sync when backend available

## 🧪 Testing

### Manual Test Checklist
- [ ] Register and login
- [ ] Create subscription
- [ ] Search/filter subscriptions
- [ ] Edit subscription
- [ ] Delete subscription
- [ ] Check payment due warnings
- [ ] Logout functionality
- [ ] Offline mode

### Test with curl
```bash
# Register
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"John","email":"john@test.com","password":"test123"}'

# Login (get token)
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"john@test.com","password":"test123"}'

# Create subscription (replace TOKEN)
curl -X POST http://localhost:5000/api/subscriptions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer TOKEN" \
  -d '{"name":"Netflix","price":15.99,"renewalDate":"2026-05-06","autoPay":true}'
```

## ⚙️ Environment Variables

### Frontend (.env)
```
REACT_APP_API_URL=http://localhost:5000/api
```

### Backend (backend/.env)
```
MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/db
JWT_SECRET=your-secret-key
PORT=5000
NODE_ENV=development
CORS_ORIGIN=http://localhost:3000
```

## 🐛 Troubleshooting

| Issue | Solution |
|-------|----------|
| Cannot connect to MongoDB | Check MONGODB_URI in .env, verify IP whitelist in Atlas |
| Port 5000 already in use | Change PORT in backend .env |
| CORS error | Verify CORS_ORIGIN matches frontend URL |
| Token invalid | Check JWT_SECRET is correct |
| Backend not reachable | Ensure backend is running and REACT_APP_API_URL is correct |

## 📦 Dependencies

### Frontend
- react, react-dom, react-router-dom

### Backend
- express, mongoose, bcryptjs, jsonwebtoken, cors, dotenv, express-validator

## 🚢 Deployment

### Frontend (Vercel/Netlify)
1. Push to GitHub
2. Connect repo to Vercel/Netlify
3. Set REACT_APP_API_URL env variable
4. Deploy

### Backend (Heroku/Railway/Render)
1. Connect GitHub repo
2. Set environment variables
3. Deploy

## 📝 API Response Format

### Success Response
```json
{
  "success": true,
  "data": {},
  "token": "jwt-token"
}
```

### Error Response
```json
{
  "success": false,
  "error": "Error message"
}
```

## 🎨 UI Features
- Black background with white cards
- Red accent color (#ff6b6b)
- Smooth animations and transitions
- Responsive design for mobile
- Hover effects on cards and buttons
- Color-coded status badges (Active/Paused/Cancelled)

## 🔄 Data Flow
```
User Login → JWT Token → Stored in localStorage
                        ↓
API Request → Bearer Token in Header
                        ↓
Backend Validates Token & Filters by userId
                        ↓
Database Query → Response
                        ↓
Frontend Updates State & localStorage
```

## 📚 Learn More
- [React Documentation](https://react.dev)
- [Express.js Guide](https://expressjs.com)
- [MongoDB Atlas Docs](https://docs.atlas.mongodb.com)
- [JWT Introduction](https://jwt.io/introduction)

## 📄 License
MIT License - Open source and free to use

## 🤝 Contributing
Contributions welcome! Please feel free to submit issues and pull requests.

---

**Created with ❤️ for subscription management**
